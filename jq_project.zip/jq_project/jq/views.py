from django.shortcuts import render
from django.http import JsonResponse
from .models import Feedback

# Create your views here.
def index(request):
    feedbacks = Feedback.objects.all()
    return render(request, 'home.html', {'feedbacks': feedbacks})

def add_feedback(request):
    if request.method == 'POST':
        feedback=Feedback.objects.create(
        name=request.POST.get('name'),
        usn=request.POST.get('usn'),
        email=request.POST.get('email'),
        branch=request.POST.get('branch'),
        satisfaction=request.POST.get('satisfaction'),
        recommend=request.POST.get('recommend'),
        comments=request.POST.get('comments'),
        )
    
    return JsonResponse({
        'id':feedback.id,
        'name':feedback.name,
        'usn':feedback.usn,
        'email':feedback.email,
        'branch':feedback.branch,
        'satisfaction':feedback.satisfaction,
        'recommend':feedback.recommend,
        'comments':feedback.comments
    })
