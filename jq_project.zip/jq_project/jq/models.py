from django.db import models

# Create your models here.
class Feedback(models.Model):
    name=models.CharField(max_length=100)
    usn=models.CharField(max_length=20)
    branch=models.CharField(max_length=100)
    email=models.EmailField()

    satisfaction=models.PositiveSmallIntegerField(
        choices=[(1,"1"),(2,"2"),(3,"3"),(4,"4"),(5,"5")]
    )
    recommend = models.CharField(
    max_length=3,
    choices=[("yes", "Yes"),("no", "No")])
    comments=models.TextField()